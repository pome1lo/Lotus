const fs = require('fs');
const nodemailer = require('nodemailer');
const path = require("path");

const MAIL = "lotus.service.no.reply@gmail.com";
const MAIL_PASS = "xskyrxkkdvlbwugt";

const HTML_PATH = "D:\\FILES\\University\\3 course\\2term\\Course Project\\Lotus\\Microservices\\notification.service\\src\\assets\\html\\";

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
        user: MAIL,
        pass: MAIL_PASS
    }
});

async function sendMail(toMail, subject, content, isHtml = false) {
    let mailOptions = {
        from: MAIL,
        to: toMail,
        subject: subject
    };

    if (isHtml) {
        const htmlPath = path.join(HTML_PATH, content);
        console.log(htmlPath);
        mailOptions.html = fs.existsSync(htmlPath) ? fs.readFileSync(htmlPath, 'utf8') : '';
    } else {
        mailOptions.text = content;
    }

    return new Promise((resolve, reject) => {
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                reject(error);
            } else {
                resolve(info.response);
            }
        });
    });
}

module.exports = { sendMail };
